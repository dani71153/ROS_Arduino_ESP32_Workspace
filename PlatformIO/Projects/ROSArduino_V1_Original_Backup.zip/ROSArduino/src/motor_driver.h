/***************************************************************
   Motor driver function definitions - by James Nugen
   *************************************************************/

#ifdef L298_MOTOR_DRIVER

 //Motor 1
  #define RIGHT_MOTOR_BACKWARD 7
  #define RIGHT_MOTOR_FORWARD  8
  #define RIGHT_MOTOR_ENABLE 5  

//Motor 2
  #define LEFT_MOTOR_BACKWARD  A13
  #define LEFT_MOTOR_FORWARD   A12
  #define LEFT_MOTOR_ENABLE 44

#endif

void initMotorController();
void setMotorSpeed(int i, int spd);
void setMotorSpeeds(int leftSpeed, int rightSpeed);
